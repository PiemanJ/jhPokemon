# jhPokemon
 Pay by bank engineering challenge

I have only set it up to run on Windows (I only have a Windows environment) althought the project does include a Docker file.

I havent had time to add any xUnit tests yet. I will try to add some! I am usually a big advocate of TDD, but have only had very limited time... (BTW, I don't accept this as an excuse from my dev team...)

I have left the default Get in place which returns a short list of dummy objects - this would obviously be removed before promoting the code from my local environment.